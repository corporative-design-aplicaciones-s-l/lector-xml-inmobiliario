<?php
return [
    'env' => getenv('APP_ENV') ?: 'dev',
    'debug' => true
];
