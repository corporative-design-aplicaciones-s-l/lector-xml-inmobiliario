<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><title>Home</title></head>
<body>
  <h1>Hola MVC</h1>
</body>
</html>
